It is AngelScript compiler for FOnline scripts.
You can integrate his in most aviable IDE.
I am do it on MSVS and Code::Blocks (http://www.codeblocks.org/), but best choise is last.
Also you can edit in Notepad and compile from command line (start compiler without parameters and read syntax).
Include "-d __CLIENT" key on client script compilation.
Key for preprocessed file generation: "-p filename.txt".